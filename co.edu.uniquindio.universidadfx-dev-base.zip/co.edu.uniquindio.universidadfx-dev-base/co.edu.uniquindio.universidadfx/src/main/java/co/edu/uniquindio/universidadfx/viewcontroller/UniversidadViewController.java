package co.edu.uniquindio.universidadfx.viewcontroller;

public class UniversidadViewController {
}
