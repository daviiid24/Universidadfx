package co.edu.uniquindio.universidadfx.model;

public class Rector extends Persona {
}
