package co.edu.uniquindio.universidadfx.model;

public class Curso {
}
